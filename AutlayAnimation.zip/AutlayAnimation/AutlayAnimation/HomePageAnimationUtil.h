//
//  HomePageAnimationUtil.h
//  AutlayAnimation
//
//  Created by win on 16/2/24.
//  Copyright © 2016年 win. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface HomePageAnimationUtil : NSObject
+(void)titleLabelAnimationWithLable:(UILabel *)lable withView:(UIView *)view;
+(void)textfieldBottomLineAnimationWithConstraint:(NSLayoutConstraint *)constraint WithView:(UIView *)view
;
+(void)iconAnimationWithLable:(UIImageView *)image withView:(UIView *)view;

+(void)tipsLabelMaskAnimation:(UIView *)view withBeginTime:(NSTimeInterval)beginTime;
+(void)registerButtonWidthAnimation:(UIButton *)button withView:(UIView *)view andProgress:(CGFloat)progress;

@end
