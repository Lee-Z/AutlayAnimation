//
//  ViewController.m
//  AutlayAnimation
//
//  Created by win on 16/2/22.
//  Copyright © 2016年 win. All rights reserved.
//

#import "ViewController.h"
#import "HomePageAnimationUtil.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UILabel *topTitleLabel;
@property (weak, nonatomic) IBOutlet UILabel *bottomTitleLabel;
@property (weak, nonatomic) IBOutlet UIImageView *leftImange;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *line;
@property (weak, nonatomic) IBOutlet UILabel *topTipsLabel;
@property (weak, nonatomic) IBOutlet UIView *bottomTipsView;
@property (weak, nonatomic) IBOutlet UITextField *phoneNumberTextField;
@property (weak, nonatomic) IBOutlet UIButton *regitsterButton;


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [_phoneNumberTextField addTarget:self action:@selector(test:) forControlEvents:UIControlEventEditingChanged];
    
    // Do any additional setup after loading the view, typically from a nib.
    _topTitleLabel.transform=CGAffineTransformMakeTranslation(0, -200);
    _bottomTitleLabel.transform=CGAffineTransformMakeTranslation(0,-200);
    _leftImange.transform=CGAffineTransformMakeTranslation(-100, 0);
    _line.constant=0;
}
-(void)test:(UITextField *)TextField
{
   NSLog(@"%lu",self.phoneNumberTextField.text.length);
    
    CGFloat progpress=self.phoneNumberTextField.text.length/11.0;
    //    CGFloat progpress=0.5;
    [HomePageAnimationUtil registerButtonWidthAnimation:_regitsterButton withView:self.view andProgress:progpress];
    if(self.phoneNumberTextField.text.length>=11)
    {
        self.regitsterButton.userInteractionEnabled=YES;
        
    }
    else{
        self.regitsterButton.userInteractionEnabled=NO;
    }
        
}

-(void)viewDidappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
    
   
}
-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    [HomePageAnimationUtil titleLabelAnimationWithLable:_topTitleLabel withView:self.view];
    [HomePageAnimationUtil titleLabelAnimationWithLable:_bottomTitleLabel withView:self.view];
    [HomePageAnimationUtil iconAnimationWithLable:_leftImange withView:self.view];
    [HomePageAnimationUtil textfieldBottomLineAnimationWithConstraint:_line  WithView:self.view];
    [HomePageAnimationUtil tipsLabelMaskAnimation:_topTipsLabel withBeginTime:0];
    [HomePageAnimationUtil tipsLabelMaskAnimation:_bottomTipsView withBeginTime:1];
    
    CGFloat progpress=self.phoneNumberTextField.text.length/11.0;
    //    CGFloat progpress=0.5;
    [HomePageAnimationUtil registerButtonWidthAnimation:_regitsterButton withView:self.view andProgress:progpress];
    
  
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark -override view method
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
}

@end
