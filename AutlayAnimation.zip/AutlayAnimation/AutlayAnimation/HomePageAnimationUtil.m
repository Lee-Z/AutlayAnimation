//
//  HomePageAnimationUtil.m
//  AutlayAnimation
//
//  Created by win on 16/2/24.
//  Copyright © 2016年 win. All rights reserved.
//

#import "HomePageAnimationUtil.h"

@implementation HomePageAnimationUtil
+(void)titleLabelAnimationWithLable:(UILabel *)lable withView:(UIView *)view
{
    [UIView animateWithDuration:2.0 animations:^{
        lable.transform =CGAffineTransformIdentity;
    }];
}
+(void)textfieldBottomLineAnimationWithConstraint:(NSLayoutConstraint *)constraint WithView:(UIView *)view
{
    constraint.constant=345.0;
   [UIView animateWithDuration:2.0 animations:^{
       [view layoutIfNeeded];
   }];
}
+(void)iconAnimationWithLable:(UIImageView *)image withView:(UIView *)view
{
    [UIView animateWithDuration:2.0 animations:^{
        image.transform=CGAffineTransformIdentity;
    }];
}


+(void)registerButtonWidthAnimation:(UIButton *)button withView:(UIView *)view andProgress:(CGFloat)progress
{
    static CAShapeLayer *layer=nil;
    if (!button.layer.mask) {
        layer=[CAShapeLayer layer];
        layer.path=[UIBezierPath bezierPathWithRect:CGRectMake(0, 0, CGRectGetWidth(button.bounds) * progress, CGRectGetHeight(button.bounds))].CGPath;
        layer.fillColor=[UIColor whiteColor].CGColor;
        button.layer.mask=layer;
        
    }
    else{
        CGPathRef path=[UIBezierPath bezierPathWithRect:CGRectMake(0, 0, CGRectGetWidth(button.bounds)*progress, CGRectGetHeight(button.bounds))].CGPath;
        
        CABasicAnimation *animation=[CABasicAnimation animationWithKeyPath:@"path"];
        animation.duration=1;
        animation.fromValue=(id)layer.path;
        animation.toValue=(__bridge id _Nullable)(path);
        animation.removedOnCompletion=YES;
        //文字只显示一次然后隐藏
        //    animation.fillMode=kCAFillModeBackwards;
        
        [layer addAnimation:animation forKey:@"shapeLayerPath"];
        layer.path=path;

        
    }
}


+(void)tipsLabelMaskAnimation:(UIView *)view withBeginTime:(NSTimeInterval)beginTime
{
    CGPathRef beginPath=[UIBezierPath bezierPathWithRect:CGRectMake(0, 0, 0,CGRectGetHeight(view.bounds))].CGPath;
    CGPathRef endPath=[UIBezierPath bezierPathWithRect:CGRectMake(0, 0, CGRectGetWidth(view.bounds),CGRectGetHeight(view.bounds))].CGPath;
    
    CAShapeLayer *layer=[CAShapeLayer layer];
    layer.fillColor=[UIColor whiteColor].CGColor;
    layer.path=beginPath;
    
    view.layer.mask=layer;
    
    CABasicAnimation *animation=[CABasicAnimation animationWithKeyPath:@"path"];
    animation.duration=1;
    animation.beginTime=CACurrentMediaTime() + beginTime;
    animation.fromValue=(id)layer.path;
    animation.toValue=(__bridge id _Nullable)(endPath);
    animation.removedOnCompletion=NO;
    //文字只显示一次然后隐藏
//    animation.fillMode=kCAFillModeBackwards;
    animation.fillMode=kCAFillModeForwards;
    [layer addAnimation:animation forKey:@"shapeLayerPath"];
}
@end
